package model;

public class Participant {
    private String name;
    private String email;
    private int eventId;

    public Participant(String name, String email, int eventId) {
        this.name = name;
        this.email = email;
        this.eventId = eventId;
    }

    // Getters & Setters (optional for now)
}
