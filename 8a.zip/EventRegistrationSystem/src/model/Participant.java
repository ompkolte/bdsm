package model;

public class Participant {
    private String name;
    private String email;
    private int eventId;

    public Participant(String name, String email, int eventId) {
        this.name = name;
        this.email = email;
        this.eventId = eventId;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getEventId() { return eventId; }
}
