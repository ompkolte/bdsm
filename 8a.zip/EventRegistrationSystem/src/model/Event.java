package model;

public class Event {
    private int id;
    private String name;
    private String date;
    private int capacity;

    public Event(String name, String date, int capacity) {
        this.name = name;
        this.date = date;
        this.capacity = capacity;
    }

    public Event(int id, String name, String date, int capacity) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.capacity = capacity;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public int getCapacity() { return capacity; }

    public void setId(int id) { this.id = id; }
}
