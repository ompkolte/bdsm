package main;

import model.Event;
import model.Participant;
import service.EventService;

public class Main {
    public static void main(String[] args) {
        EventService service = new EventService();

        // Create an event
        Event event = new Event("Tech Talk", "2025-05-05", 50);
        service.createEvent(event);

        // Register participants
        for (int i = 1; i <= 5; i++) {
            Participant p = new Participant("User" + i, "user" + i + "@email.com", 1);
            service.registerParticipant(p);
        }

        // Shutdown thread pool
        service.shutdown();
    }
}
