package service;

import db.DBConnection;
import model.Event;
import model.Participant;

import java.sql.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class EventService {

    ExecutorService executor = Executors.newFixedThreadPool(5);

    public void createEvent(Event event) {
        String sql = "INSERT INTO events (name, date, capacity) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, event.getName());
            stmt.setString(2, event.getDate());
            stmt.setInt(3, event.getCapacity());

            stmt.executeUpdate();
            System.out.println("Event created: " + event.getName());

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void registerParticipant(Participant p) {
        executor.submit(() -> {
            String sql = "INSERT INTO participants (name, email, event_id) VALUES (?, ?, ?)";
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, p.getName());
                stmt.setString(2, p.getEmail());
                stmt.setInt(3, p.getEventId());

                stmt.executeUpdate();
                System.out.println("Registered: " + p.getName());

            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public void shutdown() {
        executor.shutdown();
    }
}
