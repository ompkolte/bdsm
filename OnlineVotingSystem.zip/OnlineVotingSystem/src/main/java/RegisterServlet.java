import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Voter voter = new Voter(name, email, password);
        VoterDAO voterDAO = new VoterDAO();

        if (voterDAO.registerVoter(voter)) {
            response.sendRedirect("registration_success.jsp");
        } else {
            response.sendRedirect("registration_error.jsp");
        }
    }
}
