import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VoterDAO {

    // Register a new voter
    public boolean registerVoter(Voter voter) {
        String sql = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, voter.getFullName());
            stmt.setString(2, voter.getEmail());
            stmt.setString(3, voter.getPassword());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Authenticate voter
    public Voter authenticate(String email, String password) {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ? AND is_admin = FALSE";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Voter voter = new Voter(rs.getString("full_name"), rs.getString("email"), rs.getString("password"));
                voter.setUserId(rs.getInt("user_id"));
                voter.setHasVoted(rs.getBoolean("has_voted"));
                return voter;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    // Update voting status
    public boolean updateVotingStatus(int voterId) {
        String sql = "UPDATE users SET has_voted = TRUE WHERE user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, voterId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
