package controller;

import dao.StudentDAO;
import model.Student;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/students")
public class StudentServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StudentDAO studentDAO = new StudentDAO();
        request.setAttribute("students", studentDAO.getAllStudents());
        request.getRequestDispatcher("students.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        Student student = new Student();
        student.setName(name);
        student.setCourseId(courseId);

        StudentDAO studentDAO = new StudentDAO();
        if (studentDAO.addStudent(student)) {
            response.sendRedirect("students");
        } else {
            request.setAttribute("error", "Failed to add student");
            request.getRequestDispatcher("addStudent.jsp").forward(request, response);
        }
    }
}