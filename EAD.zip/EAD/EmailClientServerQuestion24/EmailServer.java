import java.io.*;
import java.net.*;
import java.util.*;

public class EmailServer {
    private static final int PORT = 8083;
    private static Map<String, List<String>> inboxes = Collections.synchronizedMap(new HashMap<>());

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Email Server running on port " + PORT);
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                
                out.println("Welcome to Email Server");
                out.println("Available commands: SEND, CHECK, EXIT");
                out.println("END_INSTRUCTIONS");
                
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("Server received: " + inputLine);
                    
                    if (inputLine.equalsIgnoreCase("EXIT")) {
                        out.println("Goodbye!");
                        break;
                    }
                    
                    String[] tokens = inputLine.split(" ", 3);
                    if (tokens.length == 0) continue;
                    
                    String command = tokens[0].toUpperCase();
                    
                    switch (command) {
                        case "SEND":
                            if (tokens.length < 3) {
                                out.println("ERROR: Usage: SEND <recipient> <message>");
                                continue;
                            }
                            sendEmail(tokens[1], tokens[2]);
                            out.println("OK: Message sent to " + tokens[1]);
                            break;
                            
                        case "CHECK":
                            if (tokens.length < 2) {
                                out.println("ERROR: Usage: CHECK <username>");
                                continue;
                            }
                            List<String> messages = getMessages(tokens[1]);
                            if (messages.isEmpty()) {
                                out.println("No messages found for " + tokens[1]);
                            } else {
                                out.println("START_MESSAGES");
                                out.println("Messages for " + tokens[1] + ":");
                                for (String msg : messages) {
                                    out.println("- " + msg);
                                }
                                out.println("END_MESSAGES");
                            }
                            break;
                            
                        default:
                            out.println("ERROR: Unknown command");
                    }
                }
            } catch (IOException e) {
                System.err.println("Client handling error: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    System.err.println("Error closing socket: " + e.getMessage());
                }
            }
        }

        private void sendEmail(String recipient, String message) {
            inboxes.putIfAbsent(recipient, new ArrayList<>());
            inboxes.get(recipient).add(message);
            System.out.println("Stored message for " + recipient + ": " + message);
        }

        private List<String> getMessages(String username) {
            return inboxes.getOrDefault(username, new ArrayList<>());
        }
    }
}