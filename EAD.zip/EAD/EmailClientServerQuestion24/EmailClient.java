import java.io.*;
import java.net.*;
import java.util.Scanner;

public class EmailClient {
    private static final String HOST = "localhost";
    private static final int PORT = 8083;

    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {
            
            // Print server welcome message
            String line;
            while ((line = in.readLine()) != null) {
                if (line.equals("END_INSTRUCTIONS")) break;
                System.out.println(line);
            }
            
            while (true) {
                System.out.print("\nEnter command (SEND, CHECK, EXIT): ");
                String input = scanner.nextLine().trim();
                
                out.println(input);
                
                if (input.equalsIgnoreCase("EXIT")) {
                    System.out.println(in.readLine()); // Goodbye message
                    break;
                }
                
                // Handle server responses
                boolean inMessages = false;
                while ((line = in.readLine()) != null) {
                    if (line.equals("START_MESSAGES")) {
                        inMessages = true;
                        continue;
                    }
                    if (line.equals("END_MESSAGES")) {
                        break;
                    }
                    System.out.println(line);
                    if (!inMessages && (line.startsWith("ERROR") || line.startsWith("OK") || line.startsWith("No messages"))) {
                        break;
                    }
                }
            }
        } catch (UnknownHostException e) {
            System.err.println("Server not found: " + HOST);
        } catch (IOException e) {
            System.err.println("Connection error: " + e.getMessage());
        }
        System.out.println("Client terminated");
    }
}