package pc;

class SharedBuffer {
    private int item;
    private boolean available = false; // No item at start

    // Producer will call this
    public synchronized void produce(int value) {
        while (available) {
            try {
                wait(); // wait until item is consumed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        item = value;
        available = true;
        System.out.println("Produced: " + item);
        notify(); // Notify consumer
    }

    // Consumer will call this
    public synchronized int consume() {
        while (!available) {
            try {
                wait(); // wait until item is produced
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        available = false;
        System.out.println("Consumed: " + item);
        notify(); // Notify producer
        return item;
    }
}

class Producer extends Thread {
    private SharedBuffer buffer;

    public Producer(SharedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        int i = 1;
        while (i <= 5) { // Produce 5 items
            buffer.produce(i++);
            try {
                Thread.sleep(500); // Simulate time taken to produce
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Consumer extends Thread {
    private SharedBuffer buffer;

    public Consumer(SharedBuffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        int i = 1;
        while (i <= 5) { // Consume 5 items
            buffer.consume();
            try {
                Thread.sleep(800); // Simulate time taken to consume
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            i++;
        }
    }
}

public class ConsumerProducerExample {
    public static void main(String[] args) {
        SharedBuffer buffer = new SharedBuffer();

        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);

        producer.start();
        consumer.start();
    }
}
