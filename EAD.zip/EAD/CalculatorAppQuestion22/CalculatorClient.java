// CalculatorClient.java
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class CalculatorClient {
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 12345;
        
        try (
            Socket socket = new Socket(hostname, port);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner scanner = new Scanner(System.in);
        ) {
            System.out.println("Connected to Calculator Server");
            System.out.println("Enter operations in format: OPERATION NUMBER1 NUMBER2");
            System.out.println("Available operations: add, subtract, multiply, divide");
            System.out.println("Type 'exit' to quit");
            
            String userInput;
            while (true) {
                System.out.print("> ");
                userInput = scanner.nextLine();
                
                if (userInput.equalsIgnoreCase("exit")) {
                    break;
                }
                
                out.println(userInput);
                String response = in.readLine();
                System.out.println("Server response: " + response);
            }
        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + hostname);
        } catch (IOException e) {
            System.err.println("I/O error for connection to " + hostname);
            e.printStackTrace();
        }
    }
}