public class Candidate {
    private int candidateId;
    private String name;
    private String party;
    private int votes;

    // Constructor
    public Candidate(String name, String party) {
        this.name = name;
        this.party = party;
    }

    // Getters & Setters
    public int getCandidateId() { return candidateId; }
    public void setCandidateId(int id) { this.candidateId = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getParty() { return party; }
    public void setParty(String party) { this.party = party; }

    public int getVotes() { return votes; }
    public void setVotes(int votes) { this.votes = votes; }
}