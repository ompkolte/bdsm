import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CandidateDAO {
    // Method to get all candidates
    public List<Candidate> getAllCandidates() {  // Changed return type from CandidateDAO to Candidate
        List<Candidate> candidates = new ArrayList<>();  // Changed from CandidateDAO to Candidate
        String sql = "SELECT * FROM candidates";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Candidate candidate = new Candidate(rs.getString("name"), rs.getString("party"));  // Changed from CandidateDAO to Candidate
                candidate.setCandidateId(rs.getInt("candidate_id"));
                candidate.setVotes(rs.getInt("votes"));
                candidates.add(candidate);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return candidates;
    }

    // Method to increment vote count for a candidate
    public boolean incrementVoteCount(int candidateId) {
        String sql = "UPDATE candidates SET votes = votes + 1 WHERE candidate_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, candidateId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}