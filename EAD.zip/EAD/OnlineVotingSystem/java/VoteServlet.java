import java.io.IOException;
import java.util.concurrent.locks.ReentrantLock;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@SuppressWarnings("serial")
@WebServlet("/VoteServlet")
public class VoteServlet extends HttpServlet {
    // Create a lock for thread safety
    private static final ReentrantLock voteLock = new ReentrantLock();

    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        voteLock.lock(); // Thread blocks here if another vote is in progress
        try {
            String candidateIdStr = request.getParameter("candidateId");

            if (candidateIdStr == null || candidateIdStr.trim().isEmpty()) {
                response.sendRedirect("vote_error.jsp?message=No candidate selected");
                return;
            }

            int candidateId = Integer.parseInt(candidateIdStr);
            HttpSession session = request.getSession();
            Voter voter = (Voter) session.getAttribute("voter");

            if (voter != null && !voter.isHasVoted()) {
                CandidateDAO candidateDAO = new CandidateDAO();
                VoterDAO voterDAO = new VoterDAO();

                // Critical section (thread-safe voting)
                boolean voteSuccess = candidateDAO.incrementVoteCount(candidateId);
                boolean statusUpdated = voterDAO.updateVotingStatus(voter.getUserId());

                if (voteSuccess && statusUpdated) {
                    voter.setHasVoted(true);
                    session.setAttribute("voter", voter);
                    response.sendRedirect("vote_success.jsp");
                } else {
                    response.sendRedirect("vote_error.jsp?message=Voting failed");
                }
            } else {
                response.sendRedirect("already_voted.jsp");
            }
        } finally {
            voteLock.unlock(); // Always release the lock
        }
    }
}